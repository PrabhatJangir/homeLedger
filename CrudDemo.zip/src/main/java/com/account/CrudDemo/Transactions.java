package com.account.CrudDemo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Transactions {
	@Id
	@GeneratedValue
	int transactionId;
	int debitedAccount;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	int creditedAccount;
	int amount;
	public int getDebitedAccount() {
		return debitedAccount;
	}
	public void setDebitedAccount(int debitedAccount) {
		this.debitedAccount = debitedAccount;
	}
	public int getCreditedAccount() {
		return creditedAccount;
	}
	public void setCreditedAccount(int creditedAccount) {
		this.creditedAccount = creditedAccount;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}

}
